install.packages("openxlsx", dependencies = TRUE)
library("openxlsx")
xlsx_data = read.xlsx("/cloud/project/HR_Employee_Data.xlsx",
                      sheet=1,
                      colNames=TRUE)
row_indexes = which(xlsx_data$"salary" == "low" & xlsx_data$"time_spend_company" >3 )
number_of_records = length(row_indexes)
print(number_of_records)