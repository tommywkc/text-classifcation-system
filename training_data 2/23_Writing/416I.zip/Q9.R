csv_data = read.csv(
  "/cloud/project/weight-height.csv"
)
row_indexes = which(csv_data$"Height" > 70 & csv_data$"Weight" < 180)
number_of_records = length(row_indexes)
print(number_of_records)

