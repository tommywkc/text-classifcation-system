install.packages("dplyr")
library(dplyr)
data<-read.table(
  "//cloud//project//bitcoin_price_dataset.txt", sep = "|" )
colnames(data) = c("Date", "Time", "Price")
data$Price<-as.numeric(gsub("\\$","", data$Price))
filtered_data <- data%>% filter(Price>7600)
num_records <- nrow(filtered_data)
print(num_records)